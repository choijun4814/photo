import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val buildStamp = ZonedDateTime.now(ZoneId.of("Asia/Seoul"))
    .format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm:ss"))

android {
    buildFeatures { buildConfig = true }
    namespace = "com.photomove"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.photomove"
        minSdk = 30
        targetSdk = 34
        versionCode = 9
        versionName = "1.9"
        buildConfigField("String", "BUILD_DATE", "\"$buildStamp\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.mlkit:face-detection:16.1.6")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
