package com.photomove

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class Item(val uri: Uri, val path: String, val id: Long, val mod: Long)
class CacheEntry(val mod: Long, val level: Int, val res: Int) // res 1=사람있음 0=없음, level 1=빠른검사 2=꼼꼼검사

class MainActivity : Activity() {
    private val P = 0xFF6C63FF.toInt()
    private val GREEN = 0xFF10B981.toInt()
    private val INK = 0xFF1F2937.toInt()
    private val MUTE = 0xFF6B7280.toInt()
    private val BGC = 0xFFF5F6FB.toInt()
    private val FIELD = 0xFFF1F2F8.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private var d = 1f

    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var folderEdit: EditText
    private lateinit var dcimSwitch: Switch
    private lateinit var thoroughSwitch: Switch
    private lateinit var selAll: TextView
    private lateinit var moreBtn: TextView
    private lateinit var scanBtn: Button
    private lateinit var moveBtn: Button
    private lateinit var undoBtn: Button
    private lateinit var resCard: LinearLayout
    private lateinit var status: TextView
    private lateinit var note: TextView
    private lateinit var bar: ProgressBar
    private lateinit var grid: LinearLayout
    private val chips = ArrayList<TextView>()

    private val limits = intArrayOf(200, 1000, 3000, 0)
    private val labels = arrayOf("200장", "1000장", "3000장", "전체")
    private var rangeIdx = 0
    private var baseIdx = 0
    private val bases = arrayOf("Pictures", "DCIM")
    private val baseChips = ArrayList<TextView>()
    private var found: List<Item> = emptyList()
    private val selected = HashSet<Int>()
    private val painters = ArrayList<() -> Unit>()
    private val thumbPool = HashMap<Int, Bitmap>()   // 찾은 목록 위치 -> 미리보기
    private var hitOrigIdx: IntArray = IntArray(0)
    private var shown = 0
    private val WORKERS = 3
    private val PAGE = 60
    private val PREVIEW_CAP = 90
    private var toMove: List<Item> = emptyList()
    private var pending: List<Pair<Uri, String>> = emptyList()
    private var pendingIsUndo = false
    private var scanning = false
    @Volatile private var cancel = false
    private val REQ_MOVE = 77
    private val REQ_PERM = 78
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun dp(v: Int) = (v * d).toInt()
    private fun rect(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r * d }
    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rect(Color.WHITE, 20); elevation = dp(2).toFloat()
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    }
    private fun pill(label: String, color: Int, fg: Int) = Button(this).apply {
        text = label; setTextColor(fg); isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        background = rect(color, 16); stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(54)).apply { topMargin = dp(14) }
    }
    private fun enable(b: Button, on: Boolean) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.statusBarColor = BGC; window.navigationBarColor = BGC
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(28)); setBackgroundColor(BGC)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(22))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(P, 0xFFA78BFA.toInt()))
                .apply { cornerRadius = dp(24).toFloat() }
        }
        head.addView(txt("아이앨범", 26f, Color.WHITE, true))
        head.addView(txt("얼굴 인식으로 사진을 찾아\n폴더에 모아줘요", 15f, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(6), 0, dp(12)) })
        head.addView(txt("🔒 분석은 모두 폰 안에서만 해요", 12f, 0xB3FFFFFF.toInt()))
        root.addView(head)

        val set = card()
        val sp = getSharedPreferences("p", MODE_PRIVATE)
        baseIdx = sp.getInt("base", 0)
        set.addView(txt("이동할 위치", 13f, MUTE, true))
        val brow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        bases.forEachIndexed { i, b ->
            val c = txt(b, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i == 0) rightMargin = dp(8) }
                setOnClickListener { baseIdx = i; paintChips() }
            }
            baseChips.add(c); brow.addView(c)
        }
        set.addView(brow)
        folderEdit = EditText(this).apply {
            setText(sp.getString("sub", "아들사진")); hint = "하위 폴더 (예: 가족/아들)"
            textSize = 17f; setTextColor(INK); setSingleLine()
            background = rect(FIELD, 12); setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        set.addView(folderEdit)
        set.addView(txt("📂 기존 폴더에서 고르기", 14f, P, true).apply {
            setPadding(0, dp(10), 0, dp(4)); setOnClickListener { pickFolder() }
        })
        set.addView(txt("안드로이드 규칙상 사진은 Pictures나 DCIM 안으로만 옮길 수 있어요. 그 안의 하위 폴더는 자유예요.", 12f, MUTE).apply { setPadding(0, dp(4), 0, dp(14)) })
        set.addView(txt("검사 범위 (최근 사진부터)", 13f, MUTE, true))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        labels.forEachIndexed { i, l ->
            val c = txt(l, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i < 3) rightMargin = dp(8) }
                setOnClickListener { rangeIdx = i; paintChips() }
            }
            chips.add(c); row.addView(c)
        }
        set.addView(row); paintChips()
        set.addView(txt("처음엔 200장으로 시험해 보세요", 12f, MUTE).apply { setPadding(0, dp(6), 0, dp(10)) })
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sw.addView(txt("카메라 사진만 (DCIM)", 15f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
        dcimSwitch = Switch(this).apply { isChecked = true; thumbTintList = ColorStateList.valueOf(P) }
        sw.addView(dcimSwitch)
        set.addView(sw)
        val sw2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0)
        }
        sw2.addView(txt("꼼꼼히 찾기 (작은 얼굴·옆모습까지)", 15f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
        thoroughSwitch = Switch(this).apply { isChecked = sp.getBoolean("thorough", true); thumbTintList = ColorStateList.valueOf(P) }
        sw2.addView(thoroughSwitch)
        set.addView(sw2)
        set.addView(txt("끄면 더 빨라지지만 멀리 있는 작은 얼굴은 놓칠 수 있어요. 한번 검사한 사진은 기억해서 다음엔 건너뛰어요.", 12f, MUTE).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(set)

        scanBtn = pill("사람 사진 찾기", P, Color.WHITE).apply { setOnClickListener { onScanClick() } }
        root.addView(scanBtn)

        resCard = card().apply { visibility = View.GONE }
        status = txt("", 17f, INK, true)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(P)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(10)).apply { topMargin = dp(10) }
        }
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        selAll = txt("전체 해제", 14f, P, true).apply {
            gravity = Gravity.END; setPadding(0, dp(10), 0, 0); visibility = View.GONE
            setOnClickListener {
                if (selected.size == found.size) { selected.clear(); text = "전체 선택" }
                else { selected.clear(); selected.addAll(found.indices); text = "전체 해제" }
                painters.forEach { it() }; refreshMove()
            }
        }
        moreBtn = txt("더 보기", 14f, P, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(4)); visibility = View.GONE
            setOnClickListener { showMore() }
        }
        note = txt("", 12f, MUTE).apply { setPadding(0, dp(10), 0, 0) }
        moveBtn = pill("이동하기", GREEN, Color.WHITE).apply { setOnClickListener { startMove() } }
        enable(moveBtn, false)
        resCard.addView(status); resCard.addView(bar); resCard.addView(selAll); resCard.addView(grid); resCard.addView(moreBtn); resCard.addView(note); resCard.addView(moveBtn)
        root.addView(resCard)

        undoBtn = pill("마지막 이동 되돌리기", Color.TRANSPARENT, MUTE).apply {
            textSize = 14f; setOnClickListener { startUndo() }
        }
        root.addView(undoBtn)
        refreshUndo()
        setContentView(ScrollView(this).apply { setBackgroundColor(BGC); addView(root) })
    }

    private fun paintChips() {
        baseChips.forEachIndexed { i, t ->
            val on = i == baseIdx
            t.background = rect(if (on) P else FIELD, 12)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
        chips.forEachIndexed { i, t ->
            val on = i == rangeIdx
            t.background = rect(if (on) P else FIELD, 12)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
    }

    private fun onScanClick() {
        if (scanning) { cancel = true; return }
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(perm), REQ_PERM); return
        }
        scan()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == REQ_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) scan()
        else { resCard.visibility = View.VISIBLE; status.text = "사진 접근 허용이 필요해요. 설정에서 '모든 사진'을 허용해 주세요." }
    }

    private fun folderPath(): String {
        var s = folderEdit.text.toString().trim().replace("\\", "/")
        for ((i, b) in bases.withIndex()) if (s == b || s.startsWith("$b/")) { baseIdx = i; s = s.removePrefix(b) }
        val sub = s.split("/").map { it.trim() }.filter { it.isNotEmpty() && it != "." && it != ".." }
            .joinToString("/").ifEmpty { "아들사진" }
        getSharedPreferences("p", MODE_PRIVATE).edit().putInt("base", baseIdx).putString("sub", sub).apply()
        folderEdit.setText(sub); paintChips()
        return "${bases[baseIdx]}/$sub/"
    }

    private fun pickFolder() {
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            android.widget.Toast.makeText(this, "먼저 '사람 사진 찾기'로 사진 접근을 허용해 주세요", android.widget.Toast.LENGTH_SHORT).show(); return
        }
        exec.execute {
            val dirs = java.util.TreeSet<String>()
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media.RELATIVE_PATH), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val p = c.getString(0) ?: continue
                    if (bases.any { p.startsWith("$it/") }) dirs.add(p.trimEnd('/'))
                }
            }
            val list = dirs.toList()
            runOnUiThread {
                if (list.isNotEmpty()) android.app.AlertDialog.Builder(this).setTitle("폴더 선택")
                    .setItems(list.toTypedArray()) { _, i -> folderEdit.setText(list[i]); folderPath() }.show()
            }
        }
    }

    private fun scan() {
        val target = folderPath()
        val limit = limits[rangeIdx]
        val dcim = dcimSwitch.isChecked
        val thorough = thoroughSwitch.isChecked
        getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("thorough", thorough).apply()
        scanning = true; cancel = false
        scanBtn.text = "중지"
        enable(moveBtn, false); clearGrid(); note.text = ""
        selAll.visibility = View.GONE; moreBtn.visibility = View.GONE
        resCard.visibility = View.VISIBLE; bar.visibility = View.VISIBLE; status.text = "사진 목록을 읽는 중..."
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        exec.execute {
            val items = queryImages(target, limit, dcim)
            val n = items.size
            val level = if (thorough) 2 else 1
            val cache = loadCache()
            val res = IntArray(n)            // 0=미검사 1=없음 2=있음
            val todo = ArrayList<Int>()
            for ((i, im) in items.withIndex()) {
                val e = cache[im.id]
                if (e != null && e.mod == im.mod && (e.res == 1 || e.level >= level)) res[i] = if (e.res == 1) 2 else 1
                else todo.add(i)
            }
            val cached = n - todo.size
            runOnUiThread { bar.max = maxOf(n, 1); bar.progress = cached }

            val done = AtomicInteger(0)
            val next = AtomicInteger(0)
            val hitCount = AtomicInteger(res.count { it == 2 })
            val thumbs = ConcurrentHashMap<Int, Bitmap>()
            val thumbCount = AtomicInteger(0)
            val newEntries = ConcurrentHashMap<Long, CacheEntry>()
            val lastUi = AtomicLong(0)
            val t0 = System.currentTimeMillis()
            val workers = minOf(WORKERS, maxOf(todo.size, 1))
            val pool = Executors.newFixedThreadPool(workers)
            val latch = CountDownLatch(workers)
            val maxSide = if (thorough) 1280 else 800

            repeat(workers) {
                pool.execute {
                    // 1차: 빠른 검출(큰 얼굴) / 2차: 정밀 검출(작은 얼굴, 옆모습) — 1차에서 못 찾은 사진에만 실행
                    val fast = FaceDetection.getClient(
                        FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build())
                    val acc = if (thorough) FaceDetection.getClient(
                        FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                            .setMinFaceSize(0.05f).build()) else null
                    try {
                        while (!cancel) {
                            val k = next.getAndIncrement()
                            if (k >= todo.size) break
                            val idx = todo[k]; val item = items[idx]
                            var ok = false; var face: Rect? = null
                            try {
                                val bmp = decode(item.uri, maxSide)
                                if (bmp != null) {
                                    ok = true
                                    face = bigFace(Tasks.await(fast.process(InputImage.fromBitmap(bmp, 0))), bmp, 0.05f)
                                    if (face == null && acc != null)
                                        face = bigFace(Tasks.await(acc.process(InputImage.fromBitmap(bmp, 0))), bmp, 0.045f)
                                    if (face != null && thumbCount.get() < PREVIEW_CAP) {
                                        thumbCount.incrementAndGet(); thumbs[idx] = faceThumb(bmp, face)
                                    }
                                    bmp.recycle()
                                }
                            } catch (e: Exception) { }
                            val hit = face != null
                            res[idx] = if (hit) 2 else 1
                            if (ok) newEntries[item.id] = CacheEntry(item.mod, level, if (hit) 1 else 0)
                            if (hit) hitCount.incrementAndGet()
                            val dn = done.incrementAndGet()
                            val now = System.currentTimeMillis()
                            if (dn == todo.size || now - lastUi.get() > 250) {
                                lastUi.set(now)
                                val remain = if (dn > 0) (now - t0) * (todo.size - dn) / dn / 1000 else 0L
                                val eta = if (remain >= 60) "약 ${remain / 60}분" else "${remain}초"
                                val h = hitCount.get()
                                runOnUiThread {
                                    bar.progress = cached + dn
                                    status.text = "검사 ${cached + dn} / ${n}장 · 사람 사진 ${h}장" +
                                        (if (dn < todo.size) " · 남은 시간 $eta" else "")
                                }
                            }
                        }
                    } finally { fast.close(); acc?.close(); latch.countDown() }
                }
            }
            latch.await(); pool.shutdown()

            if (newEntries.isNotEmpty()) { cache.putAll(newEntries); saveCache(cache) }

            val idxs = ArrayList<Int>()
            for (i in 0 until n) if (res[i] == 2) idxs.add(i)
            val hits = idxs.map { items[it] }
            val pool2 = HashMap<Int, Bitmap>()
            idxs.forEachIndexed { pos, orig -> thumbs[orig]?.let { pool2[pos] = it } }
            thumbs.forEach { (k, v) -> if (!idxs.contains(k)) v.recycle() }

            runOnUiThread {
                found = hits
                hitOrigIdx = idxs.toIntArray()
                thumbPool.values.forEach { if (!it.isRecycled) it.recycle() }
                thumbPool.clear(); thumbPool.putAll(pool2)
                selected.clear(); selected.addAll(hits.indices)
                scanning = false
                scanBtn.text = "사람 사진 찾기"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                bar.visibility = View.GONE
                val sec = (System.currentTimeMillis() - t0) / 1000
                status.text = (if (cancel) "중지됨 · " else "") + "사람 사진 ${hits.size}장을 찾았어요 (${sec}초)"
                note.text = if (hits.isEmpty()) "찾은 사진이 없어요. 범위나 폴더 설정을 바꿔 보세요."
                else "탭하면 제외돼요. 이동 위치: $target"
                selAll.text = "전체 해제"
                selAll.visibility = if (hits.isEmpty()) View.GONE else View.VISIBLE
                refreshMove()
                showMore()
            }
        }
    }

    private fun bigFace(faces: List<Face>, bmp: Bitmap, minRatio: Float): Rect? =
        faces.filter { it.boundingBox.width() >= bmp.width * minRatio }
            .maxByOrNull { it.boundingBox.width() }?.boundingBox

    /** 가장 큰 얼굴을 중심으로 정사각형 미리보기를 만든다. */
    private fun faceThumb(b: Bitmap, f: Rect): Bitmap {
        val s = minOf(b.width, b.height)
        val x = (f.centerX() - s / 2).coerceIn(0, b.width - s)
        val y = (f.centerY() - s / 2).coerceIn(0, b.height - s)
        val c = Bitmap.createBitmap(b, x, y, s, s)
        val t = Bitmap.createScaledBitmap(c, 256, 256, true)
        val out = if (t === b || t === c) t.copy(Bitmap.Config.ARGB_8888, false) else t
        if (c !== b && c !== out) c.recycle()
        return out
    }

    private fun clearGrid() {
        grid.removeAllViews(); painters.clear(); shown = 0
    }

    /** 다음 PAGE장 미리보기를 붙인다. */
    private fun showMore() {
        val from = shown
        val to = minOf(from + PAGE, found.size)
        if (from >= to) { moreBtn.visibility = View.GONE; return }
        shown = to
        val list = found
        exec.execute {
            val shots = ArrayList<Pair<Int, Bitmap>>()
            for (pos in from until to) {
                val bmp = thumbPool[pos] ?: try {
                    contentResolver.loadThumbnail(list[pos].uri, Size(300, 300), null)
                } catch (e: Exception) { null }
                if (bmp != null) shots.add(Pair(pos, bmp))
            }
            runOnUiThread {
                if (list !== found) return@runOnUiThread
                appendThumbs(shots, from)
                val left = found.size - shown
                moreBtn.visibility = if (left > 0) View.VISIBLE else View.GONE
                moreBtn.text = "더 보기 (남은 ${left}장)"
            }
        }
    }

    private fun appendThumbs(shots: List<Pair<Int, Bitmap>>, startPos: Int) {
        val cell = (resources.displayMetrics.widthPixels - dp(32) - dp(36) - dp(16)) / 3
        for (s in shots) {
            val n = s.first
            var row = if (n % 3 == 0) null else grid.getChildAt(grid.childCount - 1) as? LinearLayout
            if (row == null) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
                }
                grid.addView(row)
            }
            row.addView(thumb(s.second, n, cell, n % 3 != 2))
        }
    }

    private fun thumb(bmp: Bitmap, idx: Int, size: Int, gap: Boolean): FrameLayout {
        val f = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { if (gap) rightMargin = dp(8) }
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rect(0xFFE5E7EB.toInt(), 14); outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }
        val ck = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.END or Gravity.TOP).apply { setMargins(0, dp(6), dp(6), 0) }
        }
        fun paint() {
            val on = idx in selected
            ck.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) P else 0x80000000.toInt()) }
            ck.text = if (on) "✓" else ""
            iv.alpha = if (on) 1f else 0.35f
        }
        paint(); painters.add(::paint)
        f.setOnClickListener {
            if (idx in selected) selected.remove(idx) else selected.add(idx)
            paint(); refreshMove()
            selAll.text = if (selected.size == found.size) "전체 해제" else "전체 선택"
        }
        f.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH)); f.addView(ck)
        return f
    }

    private fun refreshMove() {
        val n = selected.size
        moveBtn.text = "선택한 ${n}장 이동하기"
        enable(moveBtn, n > 0 && !scanning)
    }

    private fun queryImages(target: String, limit: Int, dcim: Boolean): List<Item> {
        val list = ArrayList<Item>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DATE_MODIFIED)
        val sel = if (dcim) "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" else null
        val args = if (dcim) arrayOf("DCIM/%") else null
        contentResolver.query(base, proj, sel, args, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
            val idI = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val pI = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            val mI = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
            while (c.moveToNext() && (limit <= 0 || list.size < limit)) {
                val path = c.getString(pI) ?: continue
                if (path.startsWith(target)) continue
                if (path.contains("Screenshot", true)) continue   // 스크린샷은 제외
                val id = c.getLong(idI)
                list.add(Item(ContentUris.withAppendedId(base, id), path, id, c.getLong(mI)))
            }
        }
        return list
    }

    /** ImageDecoder: 한 번에 축소 디코딩 + EXIF 회전 자동 적용 + sRGB ARGB_8888 보장 */
    private fun decode(uri: Uri, maxSide: Int): Bitmap? = try {
        val src = ImageDecoder.createSource(contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val w = info.size.width; val h = info.size.height
            val m = maxOf(w, h)
            if (m > maxSide) {
                val r = maxSide.toFloat() / m
                dec.setTargetSize(maxOf(1, (w * r).toInt()), maxOf(1, (h * r).toInt()))
            }
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            dec.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
        }
        if (bmp.config == Bitmap.Config.ARGB_8888) bmp
        else bmp.copy(Bitmap.Config.ARGB_8888, false).also { bmp.recycle() }
    } catch (e: Throwable) { null }

    private val cacheFile by lazy { File(filesDir, "scan_cache_v2.txt") }

    private fun loadCache(): HashMap<Long, CacheEntry> {
        val m = HashMap<Long, CacheEntry>()
        try {
            if (cacheFile.exists()) cacheFile.forEachLine { l ->
                val a = l.split(',')
                if (a.size == 4) m[a[0].toLong()] = CacheEntry(a[1].toLong(), a[2].toInt(), a[3].toInt())
            }
        } catch (e: Exception) { m.clear() }
        return m
    }

    private fun saveCache(m: Map<Long, CacheEntry>) {
        try {
            val tmp = File(filesDir, "scan_cache_v2.tmp")
            tmp.bufferedWriter().use { w -> for ((k, v) in m) w.write("$k,${v.mod},${v.level},${v.res}\n") }
            tmp.renameTo(cacheFile)
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        cancel = true
        super.onDestroy()
    }

    private fun startMove() {
        val target = folderPath()
        toMove = found.filterIndexed { i, _ -> i in selected }
        pendingIsUndo = false
        requestWrite(toMove.map { Pair(it.uri, target) })
    }

    private fun startUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        val moves = raw.split("\n").filter { it.contains("\t") }.map {
            val a = it.split("\t")
            Pair(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, a[0].toLong()), a[1])
        }
        pendingIsUndo = true
        requestWrite(moves)
    }

    private fun requestWrite(moves: List<Pair<Uri, String>>) {
        if (moves.isEmpty()) return
        pending = moves
        val pi = MediaStore.createWriteRequest(contentResolver, moves.map { it.first })
        startIntentSenderForResult(pi.intentSender, REQ_MOVE, null, 0, 0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MOVE) return
        resCard.visibility = View.VISIBLE
        if (resultCode != RESULT_OK) { status.text = "이동을 취소했어요"; return }
        val moves = pending; val undo = pendingIsUndo; val orig = toMove
        status.text = "이동 중..."
        exec.execute {
            var ok = 0
            var k = 0
            for ((uri, path) in moves) {
                try {
                    val v = ContentValues().apply { put(MediaStore.Images.Media.RELATIVE_PATH, path) }
                    if (contentResolver.update(uri, v, null, null) > 0) ok++
                } catch (e: Exception) { }
                k++
                if (k % 20 == 0) { val kk = k; runOnUiThread { status.text = "이동 중... $kk / ${moves.size}" } }
            }
            val sp = getSharedPreferences("p", MODE_PRIVATE).edit()
            if (undo) sp.putString("undo", "")
            else sp.putString("undo", orig.joinToString("\n") { "${ContentUris.parseId(it.uri)}\t${it.path}" })
            sp.apply()
            runOnUiThread {
                status.text = if (undo) "✓ ${ok}장을 원래 폴더로 되돌렸어요" else "✓ ${ok}장을 이동했어요"
                note.text = if (undo) "" else "갤러리에서 확인해 보세요."
                clearGrid(); selected.clear(); found = emptyList()
                selAll.visibility = View.GONE; moreBtn.visibility = View.GONE
                thumbPool.values.forEach { if (!it.isRecycled) it.recycle() }; thumbPool.clear()
                enable(moveBtn, false); moveBtn.text = "이동하기"
                refreshUndo()
            }
        }
    }

    private fun refreshUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        enable(undoBtn, raw.isNotEmpty())
    }
}
