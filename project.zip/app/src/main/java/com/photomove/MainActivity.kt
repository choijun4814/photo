package com.photomove

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

data class Item(val uri: Uri, val path: String)

class MainActivity : Activity() {
    private val P = 0xFF6C63FF.toInt()
    private val GREEN = 0xFF10B981.toInt()
    private val INK = 0xFF1F2937.toInt()
    private val MUTE = 0xFF6B7280.toInt()
    private val BGC = 0xFFF5F6FB.toInt()
    private val FIELD = 0xFFF1F2F8.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private var d = 1f

    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var folderEdit: EditText
    private lateinit var dcimSwitch: Switch
    private lateinit var scanBtn: Button
    private lateinit var moveBtn: Button
    private lateinit var undoBtn: Button
    private lateinit var resCard: LinearLayout
    private lateinit var status: TextView
    private lateinit var note: TextView
    private lateinit var bar: ProgressBar
    private lateinit var grid: LinearLayout
    private val chips = ArrayList<TextView>()

    private val limits = intArrayOf(200, 1000, 3000, 0)
    private val labels = arrayOf("200장", "1000장", "3000장", "전체")
    private var rangeIdx = 0
    private var baseIdx = 0
    private val bases = arrayOf("Pictures", "DCIM")
    private val baseChips = ArrayList<TextView>()
    private var found: List<Item> = emptyList()
    private val selected = HashSet<Int>()
    private var toMove: List<Item> = emptyList()
    private var pending: List<Pair<Uri, String>> = emptyList()
    private var pendingIsUndo = false
    private var scanning = false
    @Volatile private var cancel = false
    private val REQ_MOVE = 77
    private val REQ_PERM = 78
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun dp(v: Int) = (v * d).toInt()
    private fun rect(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r * d }
    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rect(Color.WHITE, 20); elevation = dp(2).toFloat()
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    }
    private fun pill(label: String, color: Int, fg: Int) = Button(this).apply {
        text = label; setTextColor(fg); isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        background = rect(color, 16); stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(54)).apply { topMargin = dp(14) }
    }
    private fun enable(b: Button, on: Boolean) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.statusBarColor = BGC; window.navigationBarColor = BGC
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(28)); setBackgroundColor(BGC)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(22))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(P, 0xFFA78BFA.toInt()))
                .apply { cornerRadius = dp(24).toFloat() }
        }
        head.addView(txt("아이앨범", 26f, Color.WHITE, true))
        head.addView(txt("얼굴 인식으로 사진을 찾아\n폴더에 모아줘요", 15f, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(6), 0, dp(12)) })
        head.addView(txt("🔒 분석은 모두 폰 안에서만 해요", 12f, 0xB3FFFFFF.toInt()))
        root.addView(head)

        val set = card()
        val sp = getSharedPreferences("p", MODE_PRIVATE)
        baseIdx = sp.getInt("base", 0)
        set.addView(txt("이동할 위치", 13f, MUTE, true))
        val brow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        bases.forEachIndexed { i, b ->
            val c = txt(b, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i == 0) rightMargin = dp(8) }
                setOnClickListener { baseIdx = i; paintChips() }
            }
            baseChips.add(c); brow.addView(c)
        }
        set.addView(brow)
        folderEdit = EditText(this).apply {
            setText(sp.getString("sub", "아들사진")); hint = "하위 폴더 (예: 가족/아들)"
            textSize = 17f; setTextColor(INK); setSingleLine()
            background = rect(FIELD, 12); setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        set.addView(folderEdit)
        set.addView(txt("📂 기존 폴더에서 고르기", 14f, P, true).apply {
            setPadding(0, dp(10), 0, dp(4)); setOnClickListener { pickFolder() }
        })
        set.addView(txt("안드로이드 규칙상 사진은 Pictures나 DCIM 안으로만 옮길 수 있어요. 그 안의 하위 폴더는 자유예요.", 12f, MUTE).apply { setPadding(0, dp(4), 0, dp(14)) })
        set.addView(txt("검사 범위 (최근 사진부터)", 13f, MUTE, true))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        labels.forEachIndexed { i, l ->
            val c = txt(l, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i < 3) rightMargin = dp(8) }
                setOnClickListener { rangeIdx = i; paintChips() }
            }
            chips.add(c); row.addView(c)
        }
        set.addView(row); paintChips()
        set.addView(txt("처음엔 200장으로 시험해 보세요", 12f, MUTE).apply { setPadding(0, dp(6), 0, dp(10)) })
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sw.addView(txt("카메라 사진만 (DCIM)", 15f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
        dcimSwitch = Switch(this).apply { isChecked = true; thumbTintList = ColorStateList.valueOf(P) }
        sw.addView(dcimSwitch)
        set.addView(sw)
        root.addView(set)

        scanBtn = pill("사람 사진 찾기", P, Color.WHITE).apply { setOnClickListener { onScanClick() } }
        root.addView(scanBtn)

        resCard = card().apply { visibility = View.GONE }
        status = txt("", 17f, INK, true)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(P)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(10)).apply { topMargin = dp(10) }
        }
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        note = txt("", 12f, MUTE).apply { setPadding(0, dp(10), 0, 0) }
        moveBtn = pill("이동하기", GREEN, Color.WHITE).apply { setOnClickListener { startMove() } }
        enable(moveBtn, false)
        resCard.addView(status); resCard.addView(bar); resCard.addView(grid); resCard.addView(note); resCard.addView(moveBtn)
        root.addView(resCard)

        undoBtn = pill("마지막 이동 되돌리기", Color.TRANSPARENT, MUTE).apply {
            textSize = 14f; setOnClickListener { startUndo() }
        }
        root.addView(undoBtn)
        refreshUndo()
        setContentView(ScrollView(this).apply { setBackgroundColor(BGC); addView(root) })
    }

    private fun paintChips() {
        baseChips.forEachIndexed { i, t ->
            val on = i == baseIdx
            t.background = rect(if (on) P else FIELD, 12)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
        chips.forEachIndexed { i, t ->
            val on = i == rangeIdx
            t.background = rect(if (on) P else FIELD, 12)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
    }

    private fun onScanClick() {
        if (scanning) { cancel = true; return }
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(perm), REQ_PERM); return
        }
        scan()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == REQ_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) scan()
        else { resCard.visibility = View.VISIBLE; status.text = "사진 접근 허용이 필요해요. 설정에서 '모든 사진'을 허용해 주세요." }
    }

    private fun folderPath(): String {
        var s = folderEdit.text.toString().trim().replace("\\", "/")
        for ((i, b) in bases.withIndex()) if (s == b || s.startsWith("$b/")) { baseIdx = i; s = s.removePrefix(b) }
        val sub = s.split("/").map { it.trim() }.filter { it.isNotEmpty() && it != "." && it != ".." }
            .joinToString("/").ifEmpty { "아들사진" }
        getSharedPreferences("p", MODE_PRIVATE).edit().putInt("base", baseIdx).putString("sub", sub).apply()
        folderEdit.setText(sub); paintChips()
        return "${bases[baseIdx]}/$sub/"
    }

    private fun pickFolder() {
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            android.widget.Toast.makeText(this, "먼저 '사람 사진 찾기'로 사진 접근을 허용해 주세요", android.widget.Toast.LENGTH_SHORT).show(); return
        }
        exec.execute {
            val dirs = java.util.TreeSet<String>()
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media.RELATIVE_PATH), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val p = c.getString(0) ?: continue
                    if (bases.any { p.startsWith("$it/") }) dirs.add(p.trimEnd('/'))
                }
            }
            val list = dirs.toList()
            runOnUiThread {
                if (list.isNotEmpty()) android.app.AlertDialog.Builder(this).setTitle("폴더 선택")
                    .setItems(list.toTypedArray()) { _, i -> folderEdit.setText(list[i]); folderPath() }.show()
            }
        }
    }

    private fun scan() {
        val target = folderPath()
        val limit = limits[rangeIdx]
        val dcim = dcimSwitch.isChecked
        scanning = true; cancel = false
        scanBtn.text = "중지"
        enable(moveBtn, false); grid.removeAllViews(); note.text = ""
        resCard.visibility = View.VISIBLE; bar.visibility = View.VISIBLE; status.text = "사진 목록을 읽는 중..."
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        exec.execute {
            val items = queryImages(target, limit, dcim)
            runOnUiThread { bar.max = maxOf(items.size, 1); bar.progress = 0 }
            val det = FaceDetection.getClient(
                FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
            )
            val hits = ArrayList<Item>()
            var i = 0
            for (item in items) {
                if (cancel) break
                i++
                try {
                    val bmp = decode(item.uri)
                    if (bmp != null) {
                        val faces = Tasks.await(det.process(InputImage.fromBitmap(bmp, rotation(item.uri))))
                        val minW = bmp.width * 0.08f
                        if (faces.any { it.boundingBox.width() >= minW }) hits.add(item)
                        bmp.recycle()
                    }
                } catch (e: Exception) { }
                if (i % 5 == 0 || i == items.size) {
                    val n = i; val h = hits.size
                    runOnUiThread { bar.progress = n; status.text = "검사 $n / ${items.size}장 · 사람 사진 ${h}장" }
                }
            }
            det.close()
            val shots = ArrayList<Pair<Int, Bitmap>>()
            hits.take(60).forEachIndexed { idx, item ->
                try { shots.add(Pair(idx, contentResolver.loadThumbnail(item.uri, Size(300, 300), null))) } catch (e: Exception) { }
            }
            runOnUiThread {
                found = hits
                selected.clear(); selected.addAll(hits.indices)
                scanning = false
                scanBtn.text = "사람 사진 찾기"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                bar.visibility = View.GONE
                status.text = "사람 사진 ${hits.size}장을 찾았어요"
                note.text = if (hits.isEmpty()) "찾은 사진이 없어요. 범위나 폴더 설정을 바꿔 보세요."
                else "탭하면 제외돼요 (미리보기는 앞의 60장, 나머지도 함께 이동). 이동 위치: $target"
                buildGrid(shots)
                refreshMove()
            }
        }
    }

    private fun buildGrid(shots: List<Pair<Int, Bitmap>>) {
        grid.removeAllViews()
        val cell = (resources.displayMetrics.widthPixels - dp(32) - dp(36) - dp(16)) / 3
        var row: LinearLayout? = null
        shots.forEachIndexed { n, s ->
            if (n % 3 == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
                }
                grid.addView(row)
            }
            row!!.addView(thumb(s.second, s.first, cell, n % 3 != 2))
        }
    }

    private fun thumb(bmp: Bitmap, idx: Int, size: Int, gap: Boolean): FrameLayout {
        val f = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { if (gap) rightMargin = dp(8) }
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rect(0xFFE5E7EB.toInt(), 14); outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }
        val ck = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.END or Gravity.TOP).apply { setMargins(0, dp(6), dp(6), 0) }
        }
        fun paint() {
            val on = idx in selected
            ck.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) P else 0x80000000.toInt()) }
            ck.text = if (on) "✓" else ""
            iv.alpha = if (on) 1f else 0.35f
        }
        paint()
        f.setOnClickListener { if (idx in selected) selected.remove(idx) else selected.add(idx); paint(); refreshMove() }
        f.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH)); f.addView(ck)
        return f
    }

    private fun refreshMove() {
        val n = selected.size
        moveBtn.text = "선택한 ${n}장 이동하기"
        enable(moveBtn, n > 0 && !scanning)
    }

    private fun queryImages(target: String, limit: Int, dcim: Boolean): List<Item> {
        val list = ArrayList<Item>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH)
        contentResolver.query(base, proj, null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
            val idI = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val pI = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            while (c.moveToNext() && (limit <= 0 || list.size < limit)) {
                val path = c.getString(pI) ?: continue
                if (path.startsWith(target)) continue
                if (dcim && !path.startsWith("DCIM")) continue
                list.add(Item(ContentUris.withAppendedId(base, c.getLong(idI)), path))
            }
        }
        return list
    }

    private fun decode(uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        val m = maxOf(o.outWidth, o.outHeight)
        while (m / s > 1024) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun rotation(uri: Uri): Int = try {
        contentResolver.openInputStream(uri)?.use { s ->
            when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90; 3 -> 180; 8 -> 270; else -> 0
            }
        } ?: 0
    } catch (e: Exception) { 0 }

    private fun startMove() {
        val target = folderPath()
        toMove = found.filterIndexed { i, _ -> i in selected }
        pendingIsUndo = false
        requestWrite(toMove.map { Pair(it.uri, target) })
    }

    private fun startUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        val moves = raw.split("\n").filter { it.contains("\t") }.map {
            val a = it.split("\t")
            Pair(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, a[0].toLong()), a[1])
        }
        pendingIsUndo = true
        requestWrite(moves)
    }

    private fun requestWrite(moves: List<Pair<Uri, String>>) {
        if (moves.isEmpty()) return
        pending = moves
        val pi = MediaStore.createWriteRequest(contentResolver, moves.map { it.first })
        startIntentSenderForResult(pi.intentSender, REQ_MOVE, null, 0, 0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MOVE) return
        resCard.visibility = View.VISIBLE
        if (resultCode != RESULT_OK) { status.text = "이동을 취소했어요"; return }
        val moves = pending; val undo = pendingIsUndo; val orig = toMove
        status.text = "이동 중..."
        exec.execute {
            var ok = 0
            for ((uri, path) in moves) {
                try {
                    val v = ContentValues().apply { put(MediaStore.Images.Media.RELATIVE_PATH, path) }
                    if (contentResolver.update(uri, v, null, null) > 0) ok++
                } catch (e: Exception) { }
            }
            val sp = getSharedPreferences("p", MODE_PRIVATE).edit()
            if (undo) sp.putString("undo", "")
            else sp.putString("undo", orig.joinToString("\n") { "${ContentUris.parseId(it.uri)}\t${it.path}" })
            sp.apply()
            runOnUiThread {
                status.text = if (undo) "✓ ${ok}장을 원래 폴더로 되돌렸어요" else "✓ ${ok}장을 이동했어요"
                note.text = if (undo) "" else "갤러리에서 확인해 보세요."
                grid.removeAllViews(); selected.clear(); found = emptyList()
                enable(moveBtn, false); moveBtn.text = "이동하기"
                refreshUndo()
            }
        }
    }

    private fun refreshUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        enable(undoBtn, raw.isNotEmpty())
    }
}
