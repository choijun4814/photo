package com.photomove

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

data class Item(val uri: Uri, val path: String)

class MainActivity : Activity() {
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var folderEdit: EditText
    private lateinit var rangeSpin: Spinner
    private lateinit var dcimOnly: CheckBox
    private lateinit var scanBtn: Button
    private lateinit var moveBtn: Button
    private lateinit var undoBtn: Button
    private lateinit var status: TextView
    private lateinit var thumbs: LinearLayout

    private val limits = intArrayOf(200, 1000, 3000, 0)
    private val labels = arrayOf("최근 200장 (시험용)", "최근 1000장", "최근 3000장", "전체")
    private var found: List<Item> = emptyList()
    private var pending: List<Pair<Uri, String>> = emptyList()
    private var pendingIsUndo = false
    private var scanning = false
    @Volatile private var cancel = false
    private val REQ_MOVE = 77
    private val REQ_PERM = 78
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "사람 사진 찾아서 폴더로 이동"; textSize = 20f })
        folderEdit = EditText(this).apply { setText("아들사진"); hint = "이동할 폴더 이름 (Pictures 안)" }
        root.addView(folderEdit)
        rangeSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
        }
        root.addView(rangeSpin)
        dcimOnly = CheckBox(this).apply { text = "카메라 사진만 (DCIM)"; isChecked = true }
        root.addView(dcimOnly)
        scanBtn = Button(this).apply { text = "사람 사진 찾기"; setOnClickListener { onScanClick() } }
        root.addView(scanBtn)
        status = TextView(this).apply { text = "먼저 '최근 200장'으로 시험해 보세요."; setPadding(0, pad, 0, pad) }
        root.addView(status)
        thumbs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { addView(thumbs) })
        moveBtn = Button(this).apply { text = "찾은 사진 이동"; isEnabled = false; setOnClickListener { startMove() } }
        root.addView(moveBtn)
        undoBtn = Button(this).apply { text = "마지막 이동 되돌리기"; setOnClickListener { startUndo() } }
        root.addView(undoBtn)
        refreshUndo()
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun onScanClick() {
        if (scanning) { cancel = true; return }
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(perm), REQ_PERM); return
        }
        scan()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == REQ_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) scan()
        else status.text = "사진 접근을 허용해야 해요. (설정에서 '모든 사진' 허용)"
    }

    private fun folderPath(): String {
        val f = folderEdit.text.toString().trim().ifEmpty { "아들사진" }
        return "Pictures/$f/"
    }

    private fun scan() {
        val target = folderPath()
        val limit = limits[rangeSpin.selectedItemPosition]
        val dcim = dcimOnly.isChecked
        scanning = true; cancel = false
        scanBtn.text = "중지"; moveBtn.isEnabled = false
        thumbs.removeAllViews()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        exec.execute {
            val items = queryImages(target, limit, dcim)
            val det = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
            )
            val hits = ArrayList<Item>()
            var i = 0
            for (item in items) {
                if (cancel) break
                i++
                try {
                    val bmp = decode(item.uri)
                    if (bmp != null) {
                        val faces = Tasks.await(det.process(InputImage.fromBitmap(bmp, rotation(item.uri))))
                        val minW = bmp.width * 0.08f
                        if (faces.any { it.boundingBox.width() >= minW }) hits.add(item)
                        bmp.recycle()
                    }
                } catch (e: Exception) { }
                if (i % 5 == 0 || i == items.size) {
                    val n = i; val h = hits.size
                    runOnUiThread { status.text = "검사 $n/${items.size} · 사람 사진 ${h}장" }
                }
            }
            det.close()
            val shots = ArrayList<Bitmap>()
            for (item in hits.take(12)) {
                try { shots.add(contentResolver.loadThumbnail(item.uri, Size(240, 240), null)) } catch (e: Exception) { }
            }
            runOnUiThread {
                found = hits
                scanning = false
                scanBtn.text = "사람 사진 찾기"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                status.text = "사람 사진 ${hits.size}장 / 검사 ${i}장. 이동하면 '$target'로 옮겨져요."
                val w = (110 * resources.displayMetrics.density).toInt()
                for (b in shots) thumbs.addView(ImageView(this).apply {
                    setImageBitmap(b); layoutParams = LinearLayout.LayoutParams(w, w).apply { rightMargin = 8 }
                    scaleType = ImageView.ScaleType.CENTER_CROP
                })
                moveBtn.isEnabled = hits.isNotEmpty()
            }
        }
    }

    private fun queryImages(target: String, limit: Int, dcim: Boolean): List<Item> {
        val list = ArrayList<Item>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH)
        contentResolver.query(base, proj, null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
            val idI = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val pI = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            while (c.moveToNext() && (limit <= 0 || list.size < limit)) {
                val path = c.getString(pI) ?: continue
                if (path.startsWith(target)) continue
                if (dcim && !path.startsWith("DCIM")) continue
                list.add(Item(ContentUris.withAppendedId(base, c.getLong(idI)), path))
            }
        }
        return list
    }

    private fun decode(uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        val m = maxOf(o.outWidth, o.outHeight)
        while (m / s > 1024) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun rotation(uri: Uri): Int = try {
        contentResolver.openInputStream(uri)?.use { s ->
            when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90; 3 -> 180; 8 -> 270; else -> 0
            }
        } ?: 0
    } catch (e: Exception) { 0 }

    private fun startMove() {
        val target = folderPath()
        pendingIsUndo = false
        requestWrite(found.map { Pair(it.uri, target) })
    }

    private fun startUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        val moves = raw.split("\n").filter { it.contains("\t") }.map {
            val a = it.split("\t")
            Pair(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, a[0].toLong()), a[1])
        }
        pendingIsUndo = true
        requestWrite(moves)
    }

    private fun requestWrite(moves: List<Pair<Uri, String>>) {
        if (moves.isEmpty()) return
        pending = moves
        val pi = MediaStore.createWriteRequest(contentResolver, moves.map { it.first })
        startIntentSenderForResult(pi.intentSender, REQ_MOVE, null, 0, 0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MOVE) return
        if (resultCode != RESULT_OK) { status.text = "이동을 취소했어요."; return }
        val moves = pending; val undo = pendingIsUndo; val orig = found
        status.text = "이동 중..."
        exec.execute {
            var ok = 0
            for ((uri, path) in moves) {
                try {
                    val v = ContentValues().apply { put(MediaStore.Images.Media.RELATIVE_PATH, path) }
                    if (contentResolver.update(uri, v, null, null) > 0) ok++
                } catch (e: Exception) { }
            }
            val sp = getSharedPreferences("p", MODE_PRIVATE).edit()
            if (undo) sp.putString("undo", "")
            else sp.putString("undo", orig.joinToString("\n") { "${ContentUris.parseId(it.uri)}\t${it.path}" })
            sp.apply()
            runOnUiThread {
                status.text = if (undo) "${ok}장을 원래 폴더로 되돌렸어요." else "${ok}장을 이동했어요. 갤러리에서 확인하세요."
                moveBtn.isEnabled = false
                if (!undo) found = emptyList()
                refreshUndo()
            }
        }
    }

    private fun refreshUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        undoBtn.isEnabled = raw.isNotEmpty()
    }
}
