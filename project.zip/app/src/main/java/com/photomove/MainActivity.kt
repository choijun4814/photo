package com.photomove

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class Item(val uri: Uri, val path: String, val id: Long, val mod: Long)
data class UtilityItem(val uri: Uri, val name: String, val path: String, val id: Long, val size: Long, val audio: Boolean)
class CacheEntry(val mod: Long, val level: Int, val res: Int) // res 1=사람있음 0=없음, level 1=빠른검사 2=꼼꼼검사

class MainActivity : Activity() {
    private val P = 0xFF246B68.toInt()       // restrained teal accent
    private val GREEN = 0xFF246B68.toInt()
    private val INK = 0xFF172B3A.toInt()    // deep slate
    private val MUTE = 0xFF71808C.toInt()
    private val BGC = 0xFFF3F6F7.toInt()
    private val FIELD = 0xFFEAF0F1.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private var d = 1f

    private val exec = Executors.newSingleThreadExecutor()
    private val thumbExec = Executors.newFixedThreadPool(2)          // 파일 목록 썸네일, 크게 보기 로딩용
    private val utilityThumbs = HashMap<String, Bitmap>()            // uri -> 썸네일
    private val utilityThumbViews = HashMap<String, ImageView>()     // uri -> 현재 화면의 썸네일 뷰
    private val utilityLoading = HashSet<String>()
    private lateinit var folderEdit: EditText
    private lateinit var dcimSwitch: Switch
    private lateinit var selAll: TextView
    private lateinit var moreBtn: TextView
    private lateinit var scanBtn: Button
    private lateinit var moveBtn: Button
    private lateinit var undoBtn: Button
    private lateinit var utilityCard: LinearLayout
    private lateinit var utilityStatus: TextView
    private lateinit var utilityList: LinearLayout
    private lateinit var utilitySelectAll: TextView
    private lateinit var utilityMoveBtn: Button
    private lateinit var utilityDeleteBtn: Button
    private var utilityItems: List<UtilityItem> = emptyList()
    private val utilitySelected = LinkedHashSet<Int>()
    private var utilityMode = ""
    private var pendingUtilityAction = ""
    private lateinit var resCard: LinearLayout
    private lateinit var status: TextView
    private lateinit var note: TextView
    private lateinit var bar: ProgressBar
    private lateinit var grid: LinearLayout
    private val chips = ArrayList<TextView>()

    private val limits = intArrayOf(200, 1000, 3000, 0)
    private val labels = arrayOf("200장", "1000장", "3000장", "전체")
    private var rangeIdx = 0
    private var baseIdx = 0
    private val bases = arrayOf("Pictures", "DCIM")
    private val baseChips = ArrayList<TextView>()
    private val levelLabels = arrayOf("빠름", "꼼꼼", "최대")   // 인식 강도 1~3
    private var levelIdx = 2
    private val levelChips = ArrayList<TextView>()
    private var found: List<Item> = emptyList()
    private val selected = HashSet<Int>()
    private val painters = ArrayList<() -> Unit>()
    private val thumbPool = HashMap<Int, Bitmap>()   // 찾은 목록 위치 -> 미리보기
    private var hitOrigIdx: IntArray = IntArray(0)
    private var shown = 0
    private val WORKERS = 3
    private val PAGE = 60
    private val PREVIEW_CAP = 90
    private var toMove: List<Item> = emptyList()
    private var pending: List<Pair<Uri, String>> = emptyList()
    private var pendingIsUndo = false
    private var scanning = false
    @Volatile private var cancel = false
    private val REQ_MOVE = 77
    private val REQ_PERM = 78
    private val REQ_UTILITY_PERM = 79
    private val REQ_UTILITY_WRITE = 80
    private val REQ_UTILITY_DELETE = 81
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun dp(v: Int) = (v * d).toInt()
    private fun rect(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r * d }
    private fun txt(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rect(Color.WHITE, 16); elevation = dp(1).toFloat()
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
    }
    private fun pill(label: String, color: Int, fg: Int) = Button(this).apply {
        text = label; setTextColor(fg); isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        background = rect(color, 12); stateListAnimator = null; minHeight = 0; minimumHeight = 0
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(50)).apply { topMargin = dp(12) }
    }
    private fun enable(b: Button, on: Boolean) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.statusBarColor = BGC; window.navigationBarColor = BGC
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(28)); setBackgroundColor(BGC)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(22), dp(22), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF17384A.toInt(), 0xFF246B68.toInt()))
                .apply { cornerRadius = dp(18).toFloat() }
        }
        head.addView(txt("PHOTO ORGANIZER  /  01", 10f, 0xFFB8D8D5.toInt(), true))
        head.addView(txt("아이앨범", 28f, Color.WHITE, true).apply { setPadding(0, dp(6), 0, 0) })
        head.addView(txt("얼굴 인식으로 가족 사진을\n빠르게 찾아 정리하세요", 14f, 0xFFE3EEEF.toInt()).apply { setPadding(0, dp(7), 0, dp(14)) })
        head.addView(txt("●  사진 분석은 기기 안에서 처리됩니다", 11f, 0xFFD0E5E2.toInt()))
        head.addView(txt("VERSION ${BuildConfig.VERSION_NAME}   ·   BUILD ${BuildConfig.BUILD_DATE}", 10f, 0xFFB8D8D5.toInt(), true).apply { setPadding(0, dp(12), 0, 0) })
        root.addView(head)

        val set = card()
        val sp = getSharedPreferences("p", MODE_PRIVATE)
        baseIdx = sp.getInt("base", 0)
        levelIdx = (sp.getInt("level", 3) - 1).coerceIn(0, 2)
        set.addView(txt("이동할 위치", 13f, MUTE, true))
        val brow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        bases.forEachIndexed { i, b ->
            val c = txt(b, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i == 0) rightMargin = dp(8) }
                setOnClickListener { baseIdx = i; paintChips() }
            }
            baseChips.add(c); brow.addView(c)
        }
        set.addView(brow)
        folderEdit = EditText(this).apply {
            setText(sp.getString("sub", "아들사진")); hint = "하위 폴더 (예: 가족/아들)"
            textSize = 17f; setTextColor(INK); setSingleLine()
            background = rect(FIELD, 12); setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        set.addView(folderEdit)
        set.addView(txt("📂 기존 폴더에서 고르기", 14f, P, true).apply {
            setPadding(0, dp(10), 0, dp(4)); setOnClickListener { pickFolder() }
        })
        set.addView(txt("안드로이드 규칙상 사진은 Pictures나 DCIM 안으로만 옮길 수 있어요. 그 안의 하위 폴더는 자유예요.", 12f, MUTE).apply { setPadding(0, dp(4), 0, dp(14)) })
        set.addView(txt("검사 범위 (최근 사진부터)", 13f, MUTE, true))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        labels.forEachIndexed { i, l ->
            val c = txt(l, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i < 3) rightMargin = dp(8) }
                setOnClickListener { rangeIdx = i; paintChips() }
            }
            chips.add(c); row.addView(c)
        }
        set.addView(row); paintChips()
        set.addView(txt("처음엔 200장으로 시험해 보세요", 12f, MUTE).apply { setPadding(0, dp(6), 0, dp(10)) })
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sw.addView(txt("카메라 사진만 (DCIM)", 15f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
        dcimSwitch = Switch(this).apply { isChecked = true; thumbTintList = ColorStateList.valueOf(P) }
        sw.addView(dcimSwitch)
        set.addView(sw)
        set.addView(txt("인식 강도", 13f, MUTE, true).apply { setPadding(0, dp(16), 0, 0) })
        val lrow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        levelLabels.forEachIndexed { i, l ->
            val c = txt(l, 14f, MUTE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i < 2) rightMargin = dp(8) }
                setOnClickListener { levelIdx = i; paintChips() }
            }
            levelChips.add(c); lrow.addView(c)
        }
        set.addView(lrow); paintChips()
        set.addView(txt("빠름: 큰 얼굴만 · 꼼꼼: 작은 얼굴까지 · 최대: 옆으로 누운 사진, 어두운 사진, 아주 작은 얼굴까지 (가장 느려요). 한번 검사한 사진은 기억해서 다음엔 건너뛰어요.", 12f, MUTE).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(set)

        scanBtn = pill("사람 사진 찾기", P, Color.WHITE).apply { setOnClickListener { onScanClick() } }
        root.addView(scanBtn)

        val utilityActions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        }
        utilityActions.addView(pill("동일 이름 파일 찾기", INK, Color.WHITE).apply {
            setOnClickListener { requestUtilityAccess("duplicates") }
        })
        utilityActions.addView(pill("통화 녹음 MP3 찾기", P, Color.WHITE).apply {
            setOnClickListener { requestUtilityAccess("recordings") }
        })
        root.addView(utilityActions)

        utilityCard = card().apply { visibility = View.GONE }
        utilityStatus = txt("", 15f, INK, true)
        utilitySelectAll = txt("전체 선택", 14f, P, true).apply {
            gravity = Gravity.END; setPadding(0, dp(12), 0, dp(8))
            setOnClickListener {
                if (utilitySelected.size == utilityItems.size) utilitySelected.clear()
                else { utilitySelected.clear(); utilitySelected.addAll(utilityItems.indices) }
                repaintUtilityList()
            }
        }
        utilityList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        utilityMoveBtn = pill("선택 파일 이동", GREEN, Color.WHITE).apply { setOnClickListener { startUtilityAction("move") } }
        utilityDeleteBtn = pill("선택 파일 삭제", 0xFFB93838.toInt(), Color.WHITE).apply { setOnClickListener { startUtilityAction("delete") } }
        enable(utilityMoveBtn, false); enable(utilityDeleteBtn, false)
        utilityCard.addView(utilityStatus); utilityCard.addView(utilitySelectAll); utilityCard.addView(utilityList)
        utilityCard.addView(utilityMoveBtn); utilityCard.addView(utilityDeleteBtn)
        root.addView(utilityCard)

        resCard = card().apply { visibility = View.GONE }
        status = txt("", 17f, INK, true)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(P)
            progressBackgroundTintList = ColorStateList.valueOf(0xFFE3E9EA.toInt())
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(7)).apply { topMargin = dp(12) }
        }
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        selAll = txt("전체 해제", 14f, P, true).apply {
            gravity = Gravity.END; setPadding(0, dp(10), 0, 0); visibility = View.GONE
            setOnClickListener {
                if (selected.size == found.size) { selected.clear(); text = "전체 선택" }
                else { selected.clear(); selected.addAll(found.indices); text = "전체 해제" }
                painters.forEach { it() }; refreshMove()
            }
        }
        moreBtn = txt("더 보기", 14f, P, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(4)); visibility = View.GONE
            setOnClickListener { showMore() }
        }
        note = txt("", 12f, MUTE).apply { setPadding(0, dp(10), 0, 0) }
        moveBtn = pill("이동하기", GREEN, Color.WHITE).apply { setOnClickListener { startMove() } }
        enable(moveBtn, false)
        resCard.addView(status); resCard.addView(bar); resCard.addView(selAll); resCard.addView(grid); resCard.addView(moreBtn); resCard.addView(note); resCard.addView(moveBtn)
        root.addView(resCard)

        undoBtn = pill("마지막 이동 되돌리기", Color.TRANSPARENT, MUTE).apply {
            textSize = 14f; setOnClickListener { startUndo() }
        }
        root.addView(undoBtn)
        refreshUndo()
        setContentView(ScrollView(this).apply { setBackgroundColor(BGC); addView(root) })
    }

    private fun paintChips() {
        baseChips.forEachIndexed { i, t ->
            val on = i == baseIdx
            t.background = rect(if (on) P else FIELD, 10)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
        chips.forEachIndexed { i, t ->
            val on = i == rangeIdx
            t.background = rect(if (on) P else FIELD, 10)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
        levelChips.forEachIndexed { i, t ->
            val on = i == levelIdx
            t.background = rect(if (on) P else FIELD, 10)
            t.setTextColor(if (on) Color.WHITE else MUTE)
        }
    }

    private fun onScanClick() {
        if (scanning) { cancel = true; return }
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(perm), REQ_PERM); return
        }
        scan()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == REQ_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) scan()
        else if (code == REQ_UTILITY_PERM && r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) searchUtility()
        else if (code == REQ_UTILITY_PERM) {
            utilityCard.visibility = View.VISIBLE
            utilityStatus.text = "사진 및 오디오 접근 권한이 필요해요. 설정에서 허용해 주세요."
        } else if (code == REQ_PERM) {
            resCard.visibility = View.VISIBLE; status.text = "사진 접근 허용이 필요해요. 설정에서 '모든 사진'을 허용해 주세요."
        }
    }

    private fun requestUtilityAccess(mode: String) {
        utilityMode = mode
        val needed = if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_AUDIO
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_UTILITY_PERM)
        else searchUtility()
    }

    private fun searchUtility() {
        utilityCard.visibility = View.VISIBLE
        utilityStatus.text = "파일을 검색하는 중..."
        utilityList.removeAllViews(); utilitySelected.clear(); utilityItems = emptyList()
        utilityThumbs.clear(); utilityThumbViews.clear(); utilityLoading.clear()
        utilityMoveBtn.text = "선택 파일 이동"; utilityDeleteBtn.text = "선택 파일 삭제"
        exec.execute {
            val all = ArrayList<UtilityItem>()
            all.addAll(queryUtilityImages())
            all.addAll(queryUtilityAudio())
            val results = if (utilityMode == "duplicates") {
                val groups = all.groupBy { baseFileName(it.name).lowercase(java.util.Locale.ROOT) }
                    .filter { it.key.isNotBlank() && it.value.size > 1 }
                groups.values.flatten().distinctBy { it.uri }
                    .sortedWith(compareBy<UtilityItem> { baseFileName(it.name).lowercase(java.util.Locale.ROOT) }.thenBy { it.name })
            } else {
                all.filter { it.audio && it.name.substringAfterLast('.', "").equals("mp3", true) &&
                    ("${it.name} ${it.path}".contains("통화", true) || "${it.name} ${it.path}".contains("녹음", true) ||
                     "${it.name} ${it.path}".contains("전화", true) || "${it.name} ${it.path}".contains("call", true) ||
                     "${it.name} ${it.path}".contains("record", true) || "${it.name} ${it.path}".contains("voice", true))
                }.sortedByDescending { it.id }
            }
            runOnUiThread {
                utilityItems = results
                utilitySelected.clear()
                utilityStatus.text = if (utilityMode == "duplicates")
                    "동일 이름 파일 ${results.size}개 · 이름(확장자 제외)이 같은 파일을 모았어요."
                else "통화 녹음 후보 MP3 ${results.size}개 · 파일명/폴더명에 통화·녹음·전화·Call·Record 등이 있는 파일"
                if (results.isEmpty()) {
                    utilityList.addView(txt("검색 결과가 없어요. 파일명이나 저장 폴더를 확인해 주세요.", 13f, MUTE).apply { setPadding(0, dp(10), 0, dp(10)) })
                } else repaintUtilityList()
            }
        }
    }

    private fun baseFileName(name: String): String = name.substringBeforeLast('.', name).trim()

    private fun queryUtilityImages(): List<UtilityItem> {
        val out = ArrayList<UtilityItem>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.SIZE)
        contentResolver.query(base, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val path = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val size = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            while (c.moveToNext()) {
                val n = c.getString(name) ?: continue
                val i = c.getLong(id)
                out.add(UtilityItem(ContentUris.withAppendedId(base, i), n, c.getString(path) ?: "", i,
                    if (c.isNull(size)) 0 else c.getLong(size), false))
            }
        }
        return out
    }

    private fun queryUtilityAudio(): List<UtilityItem> {
        val out = ArrayList<UtilityItem>()
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.SIZE)
        contentResolver.query(base, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val path = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val size = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            while (c.moveToNext()) {
                val n = c.getString(name) ?: continue
                val i = c.getLong(id)
                out.add(UtilityItem(ContentUris.withAppendedId(base, i), n, c.getString(path) ?: "", i,
                    if (c.isNull(size)) 0 else c.getLong(size), true))
            }
        }
        return out
    }

    private fun repaintUtilityList() {
        utilityList.removeAllViews()
        utilitySelectAll.text = if (utilityItems.isNotEmpty() && utilitySelected.size == utilityItems.size) "전체 해제" else "전체 선택"
        utilityItems.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rect(if (i in utilitySelected) 0xFFE2F0EE.toInt() else FIELD, 10)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) }
            }
            if (!item.audio) {
                // 사진은 썸네일을 보여준다. 썸네일을 탭하면 크게 볼 수 있다.
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = rect(0xFFD5DDE0.toInt(), 8); outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
                    layoutParams = LinearLayout.LayoutParams(dp(60), dp(60)).apply { rightMargin = dp(12) }
                    setOnClickListener { showViewer(item.uri) }
                }
                row.addView(iv)
                bindUtilityThumb(iv, item)
            }
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            textCol.addView(txt((if (item.audio) "♫  " else "") + item.name, 14f, INK, true))
            textCol.addView(txt("${item.path}  ·  ${formatBytes(item.size)}", 11f, MUTE).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(textCol)
            row.setOnClickListener {
                if (i in utilitySelected) utilitySelected.remove(i) else utilitySelected.add(i)
                repaintUtilityList()
            }
            utilityList.addView(row)
        }
        enable(utilityMoveBtn, utilitySelected.isNotEmpty())
        enable(utilityDeleteBtn, utilitySelected.isNotEmpty())
        utilityMoveBtn.text = "선택 ${utilitySelected.size}개 이동"
        utilityDeleteBtn.text = "선택 ${utilitySelected.size}개 삭제"
    }

    /** 파일 목록의 사진 썸네일을 비동기로 불러온다. 목록이 다시 그려져도 중복 로딩하지 않는다. */
    private fun bindUtilityThumb(iv: ImageView, item: UtilityItem) {
        val key = item.uri.toString()
        utilityThumbViews[key] = iv
        val cached = utilityThumbs[key]
        if (cached != null) { iv.setImageBitmap(cached); return }
        if (!utilityLoading.add(key)) return
        thumbExec.execute {
            val bmp = try { contentResolver.loadThumbnail(item.uri, Size(200, 200), null) } catch (e: Exception) { null }
            runOnUiThread {
                utilityLoading.remove(key)
                if (bmp != null) {
                    utilityThumbs[key] = bmp
                    utilityThumbViews[key]?.setImageBitmap(bmp)
                }
            }
        }
    }

    /**
     * 원본 사진을 전체 화면으로 보여준다.
     * 두 손가락으로 확대/축소, 확대 상태에서 드래그로 이동, 두 번 탭하면 확대/원래대로, 한 번 탭하면 닫힘.
     */
    private fun showViewer(uri: Uri) {
        val dlg = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val spin = ProgressBar(this)
        val hint = txt("탭하면 닫혀요 · 두 손가락으로 확대", 12f, 0xFFB0B8BE.toInt())
        frame.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(spin, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        frame.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(28) })

        var zoom = 1f
        fun applyZoom(z: Float) {
            zoom = z.coerceIn(1f, 6f)
            iv.scaleX = zoom; iv.scaleY = zoom
            if (zoom == 1f) { iv.translationX = 0f; iv.translationY = 0f }
        }
        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean { applyZoom(zoom * detector.scaleFactor); return true }
        })
        val taps = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { dlg.dismiss(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean { applyZoom(if (zoom > 1f) 1f else 2.5f); return true }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (zoom > 1f && !scaler.isInProgress) { iv.translationX -= distanceX; iv.translationY -= distanceY }
                return true
            }
        })
        frame.setOnTouchListener { _, ev -> scaler.onTouchEvent(ev); taps.onTouchEvent(ev); true }

        var loaded: Bitmap? = null
        dlg.setOnDismissListener { iv.setImageDrawable(null); loaded?.recycle(); loaded = null }
        dlg.setContentView(frame)
        dlg.show()
        thumbExec.execute {
            val bmp = decode(uri, 2400)
            runOnUiThread {
                spin.visibility = View.GONE
                if (bmp == null) { hint.text = "사진을 열 수 없어요 · 탭하면 닫혀요" }
                else if (!dlg.isShowing) bmp.recycle()
                else { loaded = bmp; iv.setImageBitmap(bmp) }
            }
        }
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024 * 1024 -> String.format(java.util.Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024 * 1024))
        bytes >= 1024L * 1024 -> String.format(java.util.Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024))
        bytes >= 1024 -> String.format(java.util.Locale.getDefault(), "%.0f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    private fun startUtilityAction(action: String) {
        if (utilitySelected.isEmpty()) return
        pendingUtilityAction = action
        val chosen = utilityItems.filterIndexed { i, _ -> i in utilitySelected }
        if (action == "delete") {
            android.app.AlertDialog.Builder(this).setTitle("파일 삭제")
                .setMessage("선택한 ${chosen.size}개 파일을 삭제할까요? 삭제는 Android 시스템 확인 화면에서 승인해야 합니다.")
                .setNegativeButton("취소", null).setPositiveButton("계속") { _, _ ->
                    if (Build.VERSION.SDK_INT >= 30) {
                        val pi = MediaStore.createDeleteRequest(contentResolver, chosen.map { it.uri })
                        startIntentSenderForResult(pi.intentSender, REQ_UTILITY_DELETE, null, 0, 0, 0)
                    } else utilityStatus.text = "이 Android 버전에서는 시스템 삭제 승인 기능을 사용할 수 없어요."
                }.show()
        } else {
            val imageTarget = folderPath()
            val audioTarget = "Music/" + folderEdit.text.toString().trim().replace("\\", "/")
                .split("/").map { it.trim() }.filter { it.isNotEmpty() && it != "." && it != ".." }.joinToString("/").ifEmpty { "아이앨범_정리" } + "/"
            android.app.AlertDialog.Builder(this).setTitle("파일 이동")
                .setMessage("선택한 ${chosen.size}개 파일을 이동할까요?\n사진: $imageTarget\nMP3: $audioTarget")
                .setNegativeButton("취소", null).setPositiveButton("이동") { _, _ ->
                    if (Build.VERSION.SDK_INT >= 30) {
                        val pi = MediaStore.createWriteRequest(contentResolver, chosen.map { it.uri })
                        startIntentSenderForResult(pi.intentSender, REQ_UTILITY_WRITE, null, 0, 0, 0)
                    } else utilityStatus.text = "이 Android 버전에서는 시스템 이동 승인 기능을 사용할 수 없어요."
                }.show()
        }
    }

    private fun applyUtilityAction(action: String) {
        val chosen = utilityItems.filterIndexed { i, _ -> i in utilitySelected }
        if (action == "delete") {
            utilityStatus.text = "삭제 승인 완료 · 목록을 새로 고치는 중..."
            searchUtility()
            return
        }
        val imageTarget = folderPath()
        val audioTarget = "Music/" + folderEdit.text.toString().trim().replace("\\", "/")
            .split("/").map { it.trim() }.filter { it.isNotEmpty() && it != "." && it != ".." }.joinToString("/").ifEmpty { "아이앨범_정리" } + "/"
        exec.execute {
            var moved = 0; var failed = 0
            for (item in chosen) {
                try {
                    val target = if (item.audio) audioTarget else imageTarget
                    val values = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, target) }
                    if (contentResolver.update(item.uri, values, null, null) > 0) moved++ else failed++
                } catch (_: Exception) { failed++ }
            }
            runOnUiThread {
                utilityStatus.text = "이동 완료 ${moved}개 · 실패 ${failed}개"
                searchUtility()
            }
        }
    }

    private fun folderPath(): String {
        var s = folderEdit.text.toString().trim().replace("\\", "/")
        for ((i, b) in bases.withIndex()) if (s == b || s.startsWith("$b/")) { baseIdx = i; s = s.removePrefix(b) }
        val sub = s.split("/").map { it.trim() }.filter { it.isNotEmpty() && it != "." && it != ".." }
            .joinToString("/").ifEmpty { "아들사진" }
        getSharedPreferences("p", MODE_PRIVATE).edit().putInt("base", baseIdx).putString("sub", sub).apply()
        folderEdit.setText(sub); paintChips()
        return "${bases[baseIdx]}/$sub/"
    }

    private fun pickFolder() {
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            android.widget.Toast.makeText(this, "먼저 '사람 사진 찾기'로 사진 접근을 허용해 주세요", android.widget.Toast.LENGTH_SHORT).show(); return
        }
        exec.execute {
            val dirs = java.util.TreeSet<String>()
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media.RELATIVE_PATH), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val p = c.getString(0) ?: continue
                    if (bases.any { p.startsWith("$it/") }) dirs.add(p.trimEnd('/'))
                }
            }
            val list = dirs.toList()
            runOnUiThread {
                if (list.isNotEmpty()) android.app.AlertDialog.Builder(this).setTitle("폴더 선택")
                    .setItems(list.toTypedArray()) { _, i -> folderEdit.setText(list[i]); folderPath() }.show()
            }
        }
    }

    private fun scan() {
        val target = folderPath()
        val limit = limits[rangeIdx]
        val dcim = dcimSwitch.isChecked
        val level = levelIdx + 1                       // 1=빠름 2=꼼꼼 3=최대
        getSharedPreferences("p", MODE_PRIVATE).edit().putInt("level", level).apply()
        scanning = true; cancel = false
        scanBtn.text = "중지"
        enable(moveBtn, false); clearGrid(); note.text = ""
        selAll.visibility = View.GONE; moreBtn.visibility = View.GONE
        resCard.visibility = View.VISIBLE; bar.visibility = View.VISIBLE; status.text = "사진 목록을 읽는 중..."
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        exec.execute {
            val items = queryImages(target, limit, dcim)
            val n = items.size
            val cache = loadCache()
            val res = IntArray(n)            // 0=미검사 1=없음 2=있음
            val todo = ArrayList<Int>()
            for ((i, im) in items.withIndex()) {
                val e = cache[im.id]
                if (e != null && e.mod == im.mod && (e.res == 1 || e.level >= level)) res[i] = if (e.res == 1) 2 else 1
                else todo.add(i)
            }
            val cached = n - todo.size
            runOnUiThread { bar.max = maxOf(n, 1); bar.progress = cached }

            val done = AtomicInteger(0)
            val next = AtomicInteger(0)
            val hitCount = AtomicInteger(res.count { it == 2 })
            val thumbs = ConcurrentHashMap<Int, Bitmap>()
            val thumbCount = AtomicInteger(0)
            val newEntries = ConcurrentHashMap<Long, CacheEntry>()
            val lastUi = AtomicLong(0)
            val t0 = System.currentTimeMillis()
            val workers = minOf(WORKERS, maxOf(todo.size, 1))
            val pool = Executors.newFixedThreadPool(workers)
            val latch = CountDownLatch(workers)
            // 강도별 디코딩 크기: 클수록 멀리 있는 작은 얼굴도 픽셀이 남는다
            val maxSide = when (level) { 1 -> 800; 2 -> 1600; else -> 2560 }

            repeat(workers) {
                pool.execute {
                    val det = Detectors(
                        FaceDetection.getClient(
                            FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL).build()),
                        if (level >= 2) FaceDetection.getClient(
                            FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                                .setMinFaceSize(0.03f).build()) else null)
                    try {
                        while (!cancel) {
                            val k = next.getAndIncrement()
                            if (k >= todo.size) break
                            val idx = todo[k]; val item = items[idx]
                            var ok = false; var hit = false
                            try {
                                val bmp = decode(item.uri, maxSide)
                                if (bmp != null) {
                                    val o = detectPerson(det, bmp, level, thumbCount.get() < PREVIEW_CAP)
                                    hit = o.hit
                                    // 검출 중 오류가 났는데 못 찾은 사진은 "사람 없음"으로 기억하지 않는다 (다음에 다시 검사)
                                    ok = o.hit || o.errors == 0
                                    val t = o.thumb
                                    if (t != null) { thumbCount.incrementAndGet(); thumbs[idx] = t }
                                    bmp.recycle()
                                }
                            } catch (e: Throwable) { }
                            res[idx] = if (hit) 2 else 1
                            if (ok) newEntries[item.id] = CacheEntry(item.mod, level, if (hit) 1 else 0)
                            if (hit) hitCount.incrementAndGet()
                            val dn = done.incrementAndGet()
                            val now = System.currentTimeMillis()
                            if (dn == todo.size || now - lastUi.get() > 250) {
                                lastUi.set(now)
                                val remain = if (dn > 0) (now - t0) * (todo.size - dn) / dn / 1000 else 0L
                                val eta = if (remain >= 60) "약 ${remain / 60}분" else "${remain}초"
                                val h = hitCount.get()
                                runOnUiThread {
                                    bar.progress = cached + dn
                                    status.text = "검사 ${cached + dn} / ${n}장 · 사람 사진 ${h}장" +
                                        (if (dn < todo.size) " · 남은 시간 $eta" else "")
                                }
                            }
                        }
                    } finally { det.close(); latch.countDown() }
                }
            }
            latch.await(); pool.shutdown()

            if (newEntries.isNotEmpty()) { cache.putAll(newEntries); saveCache(cache) }

            val idxs = ArrayList<Int>()
            for (i in 0 until n) if (res[i] == 2) idxs.add(i)
            val hits = idxs.map { items[it] }
            val pool2 = HashMap<Int, Bitmap>()
            idxs.forEachIndexed { pos, orig -> thumbs[orig]?.let { pool2[pos] = it } }
            thumbs.forEach { (k, v) -> if (!idxs.contains(k)) v.recycle() }

            runOnUiThread {
                found = hits
                hitOrigIdx = idxs.toIntArray()
                thumbPool.values.forEach { if (!it.isRecycled) it.recycle() }
                thumbPool.clear(); thumbPool.putAll(pool2)
                selected.clear(); selected.addAll(hits.indices)
                scanning = false
                scanBtn.text = "사람 사진 찾기"
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                bar.visibility = View.GONE
                val sec = (System.currentTimeMillis() - t0) / 1000
                status.text = (if (cancel) "중지됨 · " else "") + "사람 사진 ${hits.size}장을 찾았어요 (${sec}초)"
                note.text = if (hits.isEmpty()) "찾은 사진이 없어요. 범위나 폴더 설정을 바꿔 보세요."
                else "탭하면 제외/선택, 길게 누르면 원본을 크게 볼 수 있어요. 이동 위치: $target"
                selAll.text = "전체 해제"
                selAll.visibility = if (hits.isEmpty()) View.GONE else View.VISIBLE
                refreshMove()
                showMore()
            }
        }
    }

    private class Detectors(val fast: FaceDetector, val acc: FaceDetector?) {
        fun close() { fast.close(); acc?.close() }
    }

    /** hit=사람 얼굴 발견, errors=검출 호출이 실패한 횟수, thumb=얼굴 중심 미리보기(있을 때만) */
    private class Outcome(var hit: Boolean = false, var errors: Int = 0, var thumb: Bitmap? = null)

    /** 검출 호출. 실패하면 null을 돌려주고 오류 횟수를 센다. */
    private fun faces(d: FaceDetector, bmp: Bitmap, rot: Int, o: Outcome): List<Face>? = try {
        Tasks.await(d.process(InputImage.fromBitmap(bmp, rot)))
    } catch (e: Throwable) { o.errors++; null }

    /**
     * 사람 얼굴이 맞는지 눈·코·입 위치로 검증한다 (동물, 조각상, 무늬를 얼굴로 착각하는 것을 거른다).
     * - 눈 두 개 + 코 + 입이 모두 있어야 하고, 눈 간격·눈/코/입의 위아래 순서·코의 가로 위치가 사람 얼굴 비율에 맞아야 함
     * - strict=false(큰 얼굴)일 때만, 눈이 한쪽만 잡힌 옆모습도 코·입이 있으면 허용
     */
    private fun looksLikeFace(f: Face, strict: Boolean): Boolean {
        val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position
        val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position
        val nose = f.getLandmark(FaceLandmark.NOSE_BASE)?.position
        val mouth = f.getLandmark(FaceLandmark.MOUTH_BOTTOM)?.position
        if (nose == null || mouth == null) return false
        if (mouth.y <= nose.y) return false
        val w = f.boundingBox.width().toFloat()
        if (le != null && re != null) {
            val eyeD = Math.hypot((le.x - re.x).toDouble(), (le.y - re.y).toDouble()).toFloat()
            val midX = (le.x + re.x) / 2f
            val midY = (le.y + re.y) / 2f
            return eyeD >= w * 0.25f && eyeD <= w * 0.85f &&
                nose.y > midY + eyeD * 0.10f &&
                mouth.y > nose.y + eyeD * 0.10f &&
                Math.abs(nose.x - midX) <= eyeD * 0.8f
        }
        return !strict && (le != null || re != null)
    }

    /**
     * minWidthPx 이상이고 얼굴 검증을 통과한 얼굴 중 가장 큰 것의 영역.
     * 폭이 strictBelowPx보다 작은 얼굴은 엄격하게(눈 두 개 필수) 검증한다. 작은 얼굴일수록 오인식이 많기 때문.
     */
    private fun biggest(list: List<Face>?, minWidthPx: Float, strictBelowPx: Float): Rect? =
        list?.filter { it.boundingBox.width() >= minWidthPx &&
                looksLikeFace(it, it.boundingBox.width() < strictBelowPx) }
            ?.maxByOrNull { it.boundingBox.width() }?.boundingBox

    /**
     * 한 장에서 사람 얼굴을 찾는다. 앞 단계에서 찾으면 바로 끝낸다.
     *  1단계 빠른 검출 → 2단계 정밀 검출(작은 얼굴)               [꼼꼼 이상]
     *  3단계 90°/270° 회전 검출(누운 사진·옆으로 기운 얼굴)        [최대]
     *  4단계 고해상도 타일 분할 검출(멀리 있는 아주 작은 얼굴)      [최대]
     *  5단계 어두운 부분 밝기 보정 후 재검출(어두운 실내·역광)      [최대]
     */
    private fun detectPerson(det: Detectors, full: Bitmap, level: Int, makeThumb: Boolean): Outcome {
        val o = Outcome()
        fun found(src: Bitmap, r: Rect?) {
            o.hit = true
            if (makeThumb && r != null) o.thumb = try { faceThumb(src, r) } catch (e: Throwable) { null }
        }
        val longSide = maxOf(full.width, full.height)
        val whole = if (level >= 2 && longSide > 1600) {
            val r = 1600f / longSide
            try { Bitmap.createScaledBitmap(full, maxOf(1, (full.width * r).toInt()), maxOf(1, (full.height * r).toInt()), true) }
            catch (e: Throwable) { o.errors++; return o }
        } else full
        try {
            val minW = whole.width * (if (level >= 2) 0.04f else 0.05f)
            val bigW = whole.width * 0.08f          // 이보다 작은 얼굴은 엄격 검증
            // 1단계
            biggest(faces(det.fast, whole, 0, o), minW, bigW)?.let { found(whole, it); return o }
            val acc = det.acc ?: return o
            // 2단계
            biggest(faces(acc, whole, 0, o), minW, bigW)?.let { found(whole, it); return o }
            if (level < 3) return o

            // 3단계: 회전된 얼굴 (회전 후 가로 폭은 원래 세로 길이). 오인식이 많아 항상 엄격 검증
            for (rot in intArrayOf(90, 270)) {
                if (biggest(faces(acc, whole, rot, o), whole.height * 0.05f, Float.MAX_VALUE) != null) { found(whole, null); return o }
            }

            // 4단계: 원본에 가까운 해상도를 1280px 타일(25% 겹침)로 잘라 각각 검출
            val tw = minOf(1280, full.width); val th = minOf(1280, full.height)
            if (full.width > 1700 || full.height > 1700) {
                val nx = if (full.width <= tw) 1 else Math.ceil((full.width - tw) / (tw * 0.75)).toInt() + 1
                val ny = if (full.height <= th) 1 else Math.ceil((full.height - th) / (th * 0.75)).toInt() + 1
                for (iy in 0 until ny) for (ix in 0 until nx) {
                    if (cancel) return o
                    val x = if (nx == 1) 0 else ix * (full.width - tw) / (nx - 1)
                    val y = if (ny == 1) 0 else iy * (full.height - th) / (ny - 1)
                    val tile = try { Bitmap.createBitmap(full, x, y, tw, th) } catch (e: Throwable) { o.errors++; null } ?: continue
                    try {
                        val r = biggest(faces(acc, tile, 0, o), full.width * 0.025f, Float.MAX_VALUE)
                        if (r != null) { found(full, Rect(r.left + x, r.top + y, r.right + x, r.bottom + y)); return o }
                    } finally { tile.recycle() }
                }
            }

            // 5단계: 그림자 영역을 끌어올린 영상으로 재검출
            val lifted = liftShadows(whole)
            if (lifted != null) {
                try {
                    val r = biggest(faces(acc, lifted, 0, o), minW, Float.MAX_VALUE)
                    if (r != null) { found(lifted, r); return o }
                } finally { lifted.recycle() }
            }
            return o
        } finally {
            if (whole !== full) whole.recycle()
        }
    }

    /** 감마 0.55로 어두운 톤을 밝힌 복사본. 어두운 실내/역광에서 얼굴이 묻히는 것을 줄인다. */
    private fun liftShadows(src: Bitmap): Bitmap? = try {
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val lut = IntArray(256) { (255.0 * Math.pow(it / 255.0, 0.55)).toInt().coerceIn(0, 255) }
        for (i in px.indices) {
            val c = px[i]
            px[i] = (c and 0xFF000000.toInt()) or (lut[(c shr 16) and 0xFF] shl 16) or
                (lut[(c shr 8) and 0xFF] shl 8) or lut[c and 0xFF]
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        out
    } catch (e: Throwable) { null }

    /** 얼굴 중심 정사각형 미리보기. 얼굴이 작아도 보이도록 얼굴 폭의 약 3.5배 범위만 잘라낸다. */
    private fun faceThumb(b: Bitmap, f: Rect): Bitmap {
        val full = minOf(b.width, b.height)
        val s = (f.width() * 3.5f).toInt().coerceIn(minOf(full, 256), full)
        val x = (f.centerX() - s / 2).coerceIn(0, b.width - s)
        val y = (f.centerY() - s / 2).coerceIn(0, b.height - s)
        val c = Bitmap.createBitmap(b, x, y, s, s)
        val t = Bitmap.createScaledBitmap(c, 256, 256, true)
        val out = if (t === b || t === c) t.copy(Bitmap.Config.ARGB_8888, false) else t
        if (c !== b && c !== out) c.recycle()
        return out
    }

    private fun clearGrid() {
        grid.removeAllViews(); painters.clear(); shown = 0
    }

    /** 다음 PAGE장 미리보기를 붙인다. */
    private fun showMore() {
        val from = shown
        val to = minOf(from + PAGE, found.size)
        if (from >= to) { moreBtn.visibility = View.GONE; return }
        shown = to
        val list = found
        exec.execute {
            val shots = ArrayList<Pair<Int, Bitmap>>()
            for (pos in from until to) {
                val bmp = thumbPool[pos] ?: try {
                    contentResolver.loadThumbnail(list[pos].uri, Size(300, 300), null)
                } catch (e: Exception) { null }
                if (bmp != null) shots.add(Pair(pos, bmp))
            }
            runOnUiThread {
                if (list !== found) return@runOnUiThread
                appendThumbs(shots, from)
                val left = found.size - shown
                moreBtn.visibility = if (left > 0) View.VISIBLE else View.GONE
                moreBtn.text = "더 보기 (남은 ${left}장)"
            }
        }
    }

    private fun appendThumbs(shots: List<Pair<Int, Bitmap>>, startPos: Int) {
        val cell = (resources.displayMetrics.widthPixels - dp(32) - dp(36) - dp(16)) / 3
        for (s in shots) {
            val n = s.first
            var row = if (n % 3 == 0) null else grid.getChildAt(grid.childCount - 1) as? LinearLayout
            if (row == null) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
                }
                grid.addView(row)
            }
            row.addView(thumb(s.second, n, cell, n % 3 != 2))
        }
    }

    private fun thumb(bmp: Bitmap, idx: Int, size: Int, gap: Boolean): FrameLayout {
        val f = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { if (gap) rightMargin = dp(8) }
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rect(0xFFE2E8EA.toInt(), 10); outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }
        val ck = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.END or Gravity.TOP).apply { setMargins(0, dp(6), dp(6), 0) }
        }
        fun paint() {
            val on = idx in selected
            ck.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) P else 0x990F2430.toInt()) }
            ck.text = if (on) "✓" else ""
            iv.alpha = if (on) 1f else 0.52f
        }
        paint(); painters.add(::paint)
        f.setOnLongClickListener {
            val list = found
            if (idx in list.indices) showViewer(list[idx].uri)
            true
        }
        f.setOnClickListener {
            if (idx in selected) selected.remove(idx) else selected.add(idx)
            paint(); refreshMove()
            selAll.text = if (selected.size == found.size) "전체 해제" else "전체 선택"
        }
        f.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH)); f.addView(ck)
        return f
    }

    private fun refreshMove() {
        val n = selected.size
        moveBtn.text = "선택한 ${n}장 이동하기"
        enable(moveBtn, n > 0 && !scanning)
    }

    private fun queryImages(target: String, limit: Int, dcim: Boolean): List<Item> {
        val list = ArrayList<Item>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DATE_MODIFIED)
        val sel = if (dcim) "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" else null
        val args = if (dcim) arrayOf("DCIM/%") else null
        contentResolver.query(base, proj, sel, args, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
            val idI = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val pI = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            val mI = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
            while (c.moveToNext() && (limit <= 0 || list.size < limit)) {
                val path = c.getString(pI) ?: continue
                if (path.startsWith(target)) continue
                if (path.contains("Screenshot", true)) continue   // 스크린샷은 제외
                val id = c.getLong(idI)
                list.add(Item(ContentUris.withAppendedId(base, id), path, id, c.getLong(mI)))
            }
        }
        return list
    }

    /** ImageDecoder: 한 번에 축소 디코딩 + EXIF 회전 자동 적용 + sRGB ARGB_8888 보장 */
    private fun decode(uri: Uri, maxSide: Int): Bitmap? = try {
        val src = ImageDecoder.createSource(contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val w = info.size.width; val h = info.size.height
            val m = maxOf(w, h)
            if (m > maxSide) {
                val r = maxSide.toFloat() / m
                dec.setTargetSize(maxOf(1, (w * r).toInt()), maxOf(1, (h * r).toInt()))
            }
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            dec.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
        }
        if (bmp.config == Bitmap.Config.ARGB_8888) bmp
        else bmp.copy(Bitmap.Config.ARGB_8888, false).also { bmp.recycle() }
    } catch (e: Throwable) { null }

    // v4: 인식 로직을 바꿨으므로 예전 기록은 "있음"(오인식 포함)·"없음"(놓침 포함) 모두 버리고 새로 검사한다.
    private val cacheFile by lazy { File(filesDir, "scan_cache_v4.txt") }

    private fun loadCache(): HashMap<Long, CacheEntry> {
        val m = HashMap<Long, CacheEntry>()
        try {
            for (old in arrayOf("scan_cache_v2.txt", "scan_cache_v3.txt")) File(filesDir, old).delete()
            if (cacheFile.exists()) cacheFile.forEachLine { l ->
                val a = l.split(',')
                if (a.size == 4) m[a[0].toLong()] = CacheEntry(a[1].toLong(), a[2].toInt(), a[3].toInt())
            }
        } catch (e: Exception) { m.clear() }
        return m
    }

    private fun saveCache(m: Map<Long, CacheEntry>) {
        try {
            val tmp = File(filesDir, "scan_cache_v4.tmp")
            tmp.bufferedWriter().use { w -> for ((k, v) in m) w.write("$k,${v.mod},${v.level},${v.res}\n") }
            tmp.renameTo(cacheFile)
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        cancel = true
        super.onDestroy()
    }

    private fun startMove() {
        val target = folderPath()
        toMove = found.filterIndexed { i, _ -> i in selected }
        pendingIsUndo = false
        requestWrite(toMove.map { Pair(it.uri, target) })
    }

    private fun startUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        val moves = raw.split("\n").filter { it.contains("\t") }.map {
            val a = it.split("\t")
            Pair(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, a[0].toLong()), a[1])
        }
        pendingIsUndo = true
        requestWrite(moves)
    }

    private fun requestWrite(moves: List<Pair<Uri, String>>) {
        if (moves.isEmpty()) return
        pending = moves
        val pi = MediaStore.createWriteRequest(contentResolver, moves.map { it.first })
        startIntentSenderForResult(pi.intentSender, REQ_MOVE, null, 0, 0, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_UTILITY_WRITE || requestCode == REQ_UTILITY_DELETE) {
            if (resultCode == RESULT_OK) applyUtilityAction(if (requestCode == REQ_UTILITY_DELETE) "delete" else "move")
            else utilityStatus.text = "파일 작업을 취소했어요."
            return
        }
        if (requestCode != REQ_MOVE) return
        resCard.visibility = View.VISIBLE
        if (resultCode != RESULT_OK) { status.text = "이동을 취소했어요"; return }
        val moves = pending; val undo = pendingIsUndo; val orig = toMove
        status.text = "이동 중..."
        exec.execute {
            var ok = 0
            var k = 0
            for ((uri, path) in moves) {
                try {
                    val v = ContentValues().apply { put(MediaStore.Images.Media.RELATIVE_PATH, path) }
                    if (contentResolver.update(uri, v, null, null) > 0) ok++
                } catch (e: Exception) { }
                k++
                if (k % 20 == 0) { val kk = k; runOnUiThread { status.text = "이동 중... $kk / ${moves.size}" } }
            }
            val sp = getSharedPreferences("p", MODE_PRIVATE).edit()
            if (undo) sp.putString("undo", "")
            else sp.putString("undo", orig.joinToString("\n") { "${ContentUris.parseId(it.uri)}\t${it.path}" })
            sp.apply()
            runOnUiThread {
                status.text = if (undo) "✓ ${ok}장을 원래 폴더로 되돌렸어요" else "✓ ${ok}장을 이동했어요"
                note.text = if (undo) "" else "갤러리에서 확인해 보세요."
                clearGrid(); selected.clear(); found = emptyList()
                selAll.visibility = View.GONE; moreBtn.visibility = View.GONE
                thumbPool.values.forEach { if (!it.isRecycled) it.recycle() }; thumbPool.clear()
                enable(moveBtn, false); moveBtn.text = "이동하기"
                refreshUndo()
            }
        }
    }

    private fun refreshUndo() {
        val raw = getSharedPreferences("p", MODE_PRIVATE).getString("undo", "") ?: ""
        enable(undoBtn, raw.isNotEmpty())
    }
}
